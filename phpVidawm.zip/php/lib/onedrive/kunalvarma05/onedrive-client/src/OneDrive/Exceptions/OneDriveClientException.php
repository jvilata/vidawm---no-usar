<?php
namespace Kunnu\OneDrive\Exceptions;

class OneDriveClientException extends \Exception{

}