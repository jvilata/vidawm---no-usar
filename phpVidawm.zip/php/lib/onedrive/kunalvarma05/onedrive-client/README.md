OneDrive PHP Client
===================
An easy to use PHP Client for the [OneDrive API](https://dev.onedrive.com/).

<img src="https://cloud.githubusercontent.com/assets/893057/13648897/12ebf3de-e661-11e5-84e3-a86a829eba32.png">


## Get Started
Head over to the **[Getting Started](https://github.com/kunalvarma05/onedrive-client/wiki/Getting-Started-And-Installation)** Wiki section to Install and Get started.

## License
OneDrive PHP Client is licensed under The MIT License (MIT).