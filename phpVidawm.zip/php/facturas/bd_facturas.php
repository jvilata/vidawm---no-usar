<?php

	require_once("bd_facturas_class.php");

	// Initiiate Library
	$api = new bd_facturas();

	$api->analiza_method();
  
?>