<?php
# archivo: bd_properties
		 const DB_SERVER = "localhost";
		 const DB_USER = "vidawmco_gactivos";
		 const DB_PASSWORD = "b011096";
		 const DB = "vidawmco_vidawm";
 ?>