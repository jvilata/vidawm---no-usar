<?php

	require_once("bd_dashboard_class.php");

	// Initiiate Library
	$api = new bd_dashboard();

	$api->analiza_method();
  
?>