<?php

	require_once("bd_fichajes_class.php");

	
	// Initiiate Library
	$api = new bd_fichajes();
	$api->analiza_method();
?>