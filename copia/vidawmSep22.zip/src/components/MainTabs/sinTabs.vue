<template>
  <div>Seleccione opción del menú</div>
</template>

<script>
export default {
  data () {
    return {
    }
  }
}
</script>
