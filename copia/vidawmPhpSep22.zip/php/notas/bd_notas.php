<?php

	require_once("bd_notas_class.php");

	// Initiiate Library
	$api = new bd_notas();

	$api->analiza_method();
  
?>