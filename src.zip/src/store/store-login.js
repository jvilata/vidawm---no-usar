import { axiosInstance } from 'boot/axios.js'
const state = {
  loggingIn: false,
  loginError: null,
  loginSuccessful: false
}
const mutations = {
  loginStart: state => { state.loggingIn = true },
  loginStop: (state, errorMessage) => {
    state.loggingIn = false
    state.loginError = errorMessage
    state.loginSuccessful = !errorMessage
  }
}
const actions = {
  doLogin ({ commit }, loginData) {
    commit('loginStart')
    console.log(axiosInstance)
    loginData.action = 'login'
    loginData.codEmpresa = '01'
    var formData = new FormData()
    for (var key in loginData) {
      formData.append(key, loginData[key])
    }
    axiosInstance.post('/users/users.php', formData, { withCredentials: true }) // { ...loginData }
      .then((response) => {
        commit('loginStop', null)
        console.log(response)
        this.$router.replace('signin')
      })
      .catch(error => {
        commit('loginStop', error.response.data.error)
      })
  }
}

export default {
  namespaced: true,
  state,
  mutations,
  actions
}
