<template>
  <q-page padding class="row justify-center">
    <div class="gutter-sm" >
      <div class="row justify-center">
        <img alt="Gooatin" src="~assets/VIDA_color.jpg" width="400px">
      </div>
      <form @submit.prevent="loginSubmit">
        <div>
        <q-input v-model="user.email" type="email" label="E-Mail" />
        </div>
        <div>
        <q-input v-model="user.password" type="password" label="Password" />
        </div>
        <div class="row justify-center">
        <q-btn type="submit" outline rounded class="full-width" label="Sign In"/>
        </div>
        <p v-if="loggingIn">Cargando...</p>
        <p v-if="loginError">{{ loginError }}</p>
        <p v-if="loginSuccessful">Login Successful</p>
      </form>
    </div>
  </q-page>
</template>

<script>
import { mapActions, mapState } from 'vuex'
export default {
  data () {
    return {
      user: {
        email: '',
        password: ''
      }
    }
  },
  computed: {
    ...mapState([
      'loggingIn',
      'loginError',
      'loginSuccessful'
    ])
  },
  methods: {
    ...mapActions('login', ['doLogin']),
    loginSubmit () {
      this.doLogin(this.user)
    }
  }
}
</script>
