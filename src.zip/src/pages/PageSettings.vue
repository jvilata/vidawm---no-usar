  <template>
    <q-card>
        <q-tabs
          v-model="tab"
          dense
          class="text-grey"
          active-color="primary"
          indicator-color="primary"
          align="justify"
          narrow-indicator
        >
          <q-tab name="mails" label="Mails" />
          <q-tab name="alarms" label="Alarms" />
          <q-tab name="movies" label="Movies" />
        </q-tabs>

        <q-separator />

        <q-tab-panels
          v-model="tab"
          animated
          swipeable
          transition-prev="jump-up"
          transition-next="jump-up"
        >
          <q-tab-panel name="mails">
            <div class="q-pa-md">
            <q-list >
              <q-item    >
                <div class="text-h6 text-grey-8">{{title}}</div>
              </q-item>
              <q-expansion-item
                  group="somegroup"
                  icon="explore"
                  label="Filtro de búsqueda"
                  default-opened
                  header-class="text-grey-8"
              >
                <q-card>
                  <q-form @submit="getTablaAux" >
                    <q-card-section>
                      <div class="row q-mb-sm">
                        <q-input outlined v-model="taskToSubmit.name" label="Task name" class="col"
                          autofocus
                          :rules="[val => !!val || 'Campo requerido']"
                          ref="name" />
                      </div>
                      <div class="row q-mb-sm">
                        <q-input outlined v-model="taskToSubmit.dueDate"  label="dueDate" class="col">
                          <template v-slot:append>
                            <q-icon name="event" class="cursos-pointer">
                              <q-popup-proxy>
                                <q-date v-model="taskToSubmit.dueDate"/>
                              </q-popup-proxy>
                            </q-icon>
                          </template>
                        </q-input>
                      </div>
                      <div class="row q-mb-sm">
                        <q-input outlined v-model="taskToSubmit.dueTime" label="dueTime" class="col">
                          <template v-slot:append>
                            <q-icon name="access_time" class="cursos-pointer">
                              <q-popup-proxy>
                                <q-time v-model="taskToSubmit.dueTime" />
                              </q-popup-proxy>
                            </q-icon>
                          </template>
                        </q-input>
                      </div>

                    </q-card-section>
                    <q-card-actions align=right>
                        <q-btn type="submit" label="Save" color="primary"/>
                    </q-card-actions>
                  </q-form>
                </q-card>
              </q-expansion-item>
              <q-expansion-item
                  group="somegroup"
                  icon="explore"
                  label="Lista de tablas"
                  header-class="text-grey-8"
              >
                <q-table
                  class="my-sticky-header-table"
                  dense
                  virtual-scroll
                  :pagination.sync="pagination"
                  :rows-per-page-options="[0]"
                  :virtual-scroll-sticky-size-start="48"
                  row-key="id"
                  :data="tablaAux"
                  :columns="columns"
                  table-style="max-height: 80vh"
                >

                  <template v-slot:header="props">
                    <q-tr :props="props">
                      <q-th />

                      <q-th
                        v-for="col in props.cols"
                        :key="col.name"
                        :props="props"
                      >
                        {{ col.label }}
                      </q-th>
                    </q-tr>
                  </template>

                  <template v-slot:body="props">
                    <q-tr :props="props" :key="`m_${props.row.id}`">
                      <q-td>
                        Index: {{ props.row.id }}
                        <q-popup-edit v-model="props.row.valor1">
                          <q-input v-model="props.row.valor1" dense autofocus counter />
                        </q-popup-edit>
                      </q-td>

                      <q-td
                        v-for="col in props.cols"
                        :key="col.name"
                        :props="props"
                      >
                        {{ col.value }}
                      </q-td>
                    </q-tr>
                    <q-tr :props="props" :key="`e_${props.row.id}`" class="q-virtual-scroll--with-prev">
                      <q-td colspan="100%">
                        <div class="text-left">This is the second row generated from the same data: {{ props.row.valor1 }} (Index: {{ props.row.id }}).</div>
                      </q-td>
                    </q-tr>
                  </template>

                </q-table>
                <q-btn color="primary" @click="getTablaAux()" label="Make AXIOS Success Call" ></q-btn>
                <q-btn color="primary" @click="getOtro()" label="otras llamadas" ></q-btn>
              </q-expansion-item>
            </q-list>
          </div>
        </q-tab-panel>
    <q-tab-panel name="alarms">
     <div class="text-h6 text-grey-8">Alarmas</div>
     <q-card>
      <task-form v-model="tar1"/>
     </q-card>
   </q-tab-panel>
    <q-tab-panel name="movies">
     <div class="text-h6 text-grey-8">movies</div>
     <q-card>
        <task-form v-model="tar2"/>
     </q-card>
   </q-tab-panel>
   </q-tab-panels>
    </q-card>
</template>

<script>
import TaskForm from 'components/Tasks/TaskForm.vue'
export default {
  data () {
    return {
      tar1: { name: 'task1' },
      tar2: { name: 'task2' },
      tab: 'mails',
      splitterModel: 20,
      title: 'Tabla Auxiliar',
      taskToSubmit: {},
      tablaAux: [],
      columns: [
        {
          name: 'codEmpresa',
          required: true,
          label: 'codEmpresa',
          align: 'left',
          field: row => row.codEmpresa,
          format: val => `${val}`,
          sortable: true
        },
        { name: 'codTabla', align: 'center', label: 'codTabla', field: 'codTabla', sortable: true },
        { name: 'codElemento', label: 'codElemento', field: 'codElemento', sortable: true, style: 'width: 10px' },
        { name: 'valor1', label: 'valor1', field: 'valor1' },
        { name: 'valor2', label: 'valor2', field: 'valor2' }
      ],
      pagination: {
        rowsPerPage: 0
      }
    }
  },
  components: {
    'task-form': TaskForm
  },
  methods: {
    getTablaAux () {
      return this.$axios.get('tablaAuxiliar/bd_tablaAuxiliar.php/findTablaAuxFilter')
        .then(response => {
          this.tablaAux = response.data
        })
        .catch(error => {
          console.log(error)
        })
    },
    getOtro () {
      return this.$axios.get('acciones/bd_acciones.php/findAccionesFilter?idUserQuienProx=%5B%22jvilata%40edicom.es%22%5D&fechaProxHasta=2020-03-03%2013%3A35%3A37&realizada=0&maxrec=999&codEmpresa=01', { withCredentials: true })
        .then(response => {
          this.tablaAux = response.data
        })
        .catch(error => {
          console.log(error)
        })
    }
  },
  mounted () {
  }
}
</script>
<style lang="sass">
  .my-sticky-header-table
    .q-table__top,
    .q-table__bottom,
    thead tr:first-child th
      /* bg color is important for th; just specify one */
      background-color: $grey-2

    thead tr th
      position: sticky
      z-index: 1
    thead tr:first-child th
      top: 0

    /* this is when the loading indicator appears */
    &.q-table--loading thead tr:last-child th
      /* height of all previous header rows */
      top: 48px
</style>
