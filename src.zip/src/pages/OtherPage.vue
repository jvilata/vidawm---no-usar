  <template>
    <q-card>
        <q-tabs
          v-model="ltab"
          dense
          class="text-grey"
          active-color="primary"
          indicator-color="primary"
          align="justify"
          narrow-indicator
        >
          <q-tab  name="otrod" label="Otrod" />
          <q-route-tab v-for="(tab,index) in tabs" :key="index" :name="tab.name" :label="tab.label" :to="tab.link" />
        </q-tabs>

        <q-separator />
        <q-tab-panels v-model="ltab" animated>
          <q-tab-panel name="otrod">
            <prueba v-model="search"/>
          </q-tab-panel>
          <q-tab-panel v-for="(tab,index) in tabs" :key="index" :name="tab.name">
            <router-view @input="(value) => modificar(index,value)"/>
          </q-tab-panel>
        </q-tab-panels>
        <q-btn color="primary" @click="addTab" label="Añadir Tab" ></q-btn>
    </q-card>
</template>

<script>
import search from 'components/Tasks/prueba.vue'
// import Vue from 'vue'
export default {
  data () {
    return {
      search: '',
      task: [{ name: 'task1' }, { name: 'task2' }],
      task3: {},
      ltab: 'mails',
      tabs: [
        {
          name: 'mails',
          label: 'mails',
          link: '/'
        }
        /*   {
          name: 'otrod',
          label: 'otrod',
          link: { name: 'otrod', params: { index: 1, task: this.task3, isAdd: false } }
        } */
      ]
    }
  },
  methods: {
    modificar (index, value) {
      if (index > 0) {
        Object.assign(this.task[index - 1], value)
      }
    },
    addTab () {
      this.tabs.push({ name: 'tab' + this.tabs.length, label: 'tab' + this.tabs.length, link: { name: 'otro', params: { index: this.tabs.length, value: this.task[this.tabs.length - 1], isAdd: true } } })
    }
  },
  components: {
    prueba: search
  }
}
</script>
