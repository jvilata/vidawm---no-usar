<template>
  <q-layout view="hHh lpR fFf">
    <q-header elevated>
      <q-toolbar>
          <img src="~assets/VIDA_color.jpg" height="40" />
        <q-toolbar-title class="absolute-center">Awesome-Todo</q-toolbar-title>
      </q-toolbar>
    </q-header>

    <q-drawer v-model="leftDrawerOpen"
      show-if-above bordered content-class="bg-primary"
      :mini="miniState"
      @mouseover="miniState = false"
      @mouseout="miniState = true"
      :breakpoint="767"
      :width="250">
      <q-list dark>
        <q-item-label header>Navigation</q-item-label>
        <EssentialLink v-for="link in essentialLinks" :key="link.title" v-bind="link" />
      </q-list>
    </q-drawer>

    <q-footer>
      <q-tabs>
        <q-route-tab v-for="link in essentialLinks"
          :key="link.title"
          :icon="link.icon"
          :label="link.title"
          :to="link.link"
          exact />
      </q-tabs>
    </q-footer>

    <q-page-container>
      <router-view />
    </q-page-container>
  </q-layout>
</template>

<script>
import EssentialLink from 'components/EssentialLink'

export default {
  name: 'MainLayout',

  components: {
    EssentialLink
  },

  data () {
    return {
      leftDrawerOpen: false,
      miniState: false,
      essentialLinks: [
        {
          title: 'Todo',
          // caption: '',
          icon: 'list',
          link: '/'
        },
        {
          title: 'Settings',
          // caption: 'github.com/quasarframework',
          icon: 'settings',
          link: '/settings'
        },
        {
          title: 'Other',
          // caption: 'github.com/quasarframework',
          icon: 'settings',
          link: '/other'
        }
      ]
    }
  }
}
</script>

<style>
  @media screen and (min-width: 768px) {
    .q-footer {
      display: none;
    }
  }

  .q-drawer .q-router-link--exact-active {
    color: white !important;
  }
</style>
