
const routes = [
  {
    path: '/',
    component: () => import('layouts/LayoutLogin.vue'),
    children: [
      { path: '', component: () => import('pages/PageLogin.vue') }
    ]
  },
  {
    path: '/',
    component: () => import('layouts/MainLayout.vue'),
    children: [
      { path: 'signin', component: () => import('pages/TaskList.vue') },
      { path: 'settings', component: () => import('pages/PageSettings.vue') },
      {
        path: 'other',
        component: () => import('pages/OtherPage.vue'),
        children: [
          { path: 'otro/:index', name: 'otro', component: () => import('components/Tasks/TaskForm.vue'), props: true },
          { path: 'otrod', name: 'otrod', component: () => import('components/Tasks/prueba.vue'), props: true }
        ]
      }
    ]
  }
]

// Always leave this as last one
if (process.env.MODE !== 'ssr') {
  routes.push({
    path: '*',
    component: () => import('pages/Error404.vue')
  })
}

export default routes
