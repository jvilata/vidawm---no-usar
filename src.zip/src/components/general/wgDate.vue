<template>
    <q-date :locale="myLocale"
        v-model="myDate"
        today-btn
        @input="dateChange"/>
</template>
<script>
export default {
  props: ['dateValue'],
  data () {
    return {
      myLocale: {
        /* starting with Sunday */
        days: 'Domingo_Lunes_Martes_Miércoles_Jueves_Viernes_Sábado'.split('_'),
        daysShort: 'Dom_Lun_Mar_Mié_Jue_Vie_Sáb'.split('_'),
        months: 'Enero_Febrero_Marzo_Abril_Mayo_Junio_Julio_Agosto_Septiembre_Octubre_Noviembre_Diciembre'.split('_'),
        monthsShort: 'Ene_Feb_Mar_Abr_May_Jun_Jul_Ago_Sep_Oct_Nov_Dic'.split('_'),
        firstDayOfWeek: 1
      },
      myDate: ''
    }
  },
  methods: {
    dateChange (value, reason, details) {
      this.$emit('dateChange', value)
    }
  },
  mounted () {
    this.myDate = this.dateValue
  }
}
</script>
