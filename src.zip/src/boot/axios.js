import axios from 'axios'

// Vue.prototype.$axios = axios
const axiosInstance = axios.create({
  baseURL: 'http://vidawm.com/privado/php/',
  withCredentials: true,
  headers: {
    Accept: ['application/json', 'text/html', 'application/xhtml+xml', 'application/xml'],
    'Content-Type': 'application/x-www-form-urlencoded'
  }
})
axios.defaults.withCredentials = true
axiosInstance.defaults.withCredentials = true
export default ({ Vue }) => {
  Vue.prototype.$axios = axiosInstance
}
export { axiosInstance }
